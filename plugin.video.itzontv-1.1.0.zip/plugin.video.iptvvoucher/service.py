import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
from datetime import datetime, timezone, timedelta
import sys
import os
import json
import xml.etree.ElementTree as ET
import urllib.request
from time import ctime


ADDON = xbmcaddon.Addon()
IPTV_ADDON_ID = "pvr.iptvsimple"
IPTV_ADDON = xbmcaddon.Addon(IPTV_ADDON_ID)
SECRET_KEY = "Raitra123##@@Vip"
API_URL_ENDPOINT = "https://tv.it-zone.tech/api/"
addon_path = xbmcaddon.Addon().getAddonInfo('path')
pyjwt_path = os.path.join(addon_path, 'resources', 'libs', 'pyjwt')
ntplib_path = os.path.join(addon_path, 'resources', 'libs', 'ntplib')

sys.path.append(pyjwt_path)
sys.path.append(xbmcvfs.translatePath('special://home/addons/plugin.video.iptvvoucher/resources/libs'))
import ntplib



addon_data_path = os.path.join(xbmcvfs.translatePath("special://userdata"),'addon_data', 'pvr.iptvsimple')

import jwt


def update_m3u_url(new_url):
    settings_file = os.path.join(addon_data_path, "instance-settings-1.xml")

    if not os.path.exists(settings_file):
        xbmcgui.Dialog().notification("Error", "IPTV Simple Client settings file not found!", xbmcgui.NOTIFICATION_ERROR, 8000)
        return False
    
    tree = ET.parse(settings_file)
    root = tree.getroot()
    
    for setting in root.findall("setting"):
        #print the setting id and it's child value

        print(setting.get("id"), setting.get("value"))
        if setting.get("id") == "m3uUrl":
            setting.text = new_url
            break
   
    tree.write(settings_file)

def fetch_new_m3u_url(is_registered=False):
    if is_registered:
        endpoint = API_URL_ENDPOINT + "m3u"
    else:
        endpoint = API_URL_ENDPOINT + "m3u_unregistered"

    req = urllib.request.Request(endpoint)
    response = urllib.request.urlopen(req)
    response_data = json.load(response)

    return response_data["m3uUrl"]
  
def check_subscription_status():
    token = ADDON.getSetting("token")


    if not token:
        xbmcgui.Dialog().ok("Subscription Required", "You need to enter a valid subscription token to use IT ZONE TV!")
        update_m3u_url("")
        return False
    try:
        #Convert expiry date to timestamp
        decoded_payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])

        expiry_date_str = decoded_payload["expiry_date"]
        expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d")
        print("Hello world before")

        client = ntplib.NTPClient()
        response = client.request("pool.ntp.org", version=3)
        gmt_plus_3 = timezone(timedelta(hours=3))
        utc_time = datetime.fromtimestamp(response.tx_time, tz=timezone.utc)

        current_date = utc_time.astimezone(gmt_plus_3)
        expiry_date = expiry_date.astimezone(gmt_plus_3)

        
        print(current_date)
        #convert the current date to timestamp

        days_remaining = (expiry_date - current_date).days

        print(f"DAYS  REMAINING {days_remaining}")

        if days_remaining <= 0:
            xbmcgui.Dialog().ok("Subscription Expired", "Your IT ZONE TV subscription has expired! Please renew.")
            #get all exisiting instances of the setting
            update_m3u_url(fetch_new_m3u_url(False))
            return False
        elif days_remaining <= 364:
            xbmcgui.Dialog().notification("Warning", f"Your IT ZONE TV subscription expires in {int(days_remaining)} days!", xbmcgui.NOTIFICATION_WARNING, 8000)
            update_m3u_url(fetch_new_m3u_url(True))
            
            
    except Exception as e:
        # show in dialog the exception message
        print(f"Message = {e}")
        xbmcgui.Dialog().notification("Error", "An error occurred while checking subscription status!", xbmcgui.NOTIFICATION_ERROR, 8000)

    return True

class SubscriptionMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        check_subscription_status()

def run_service():
    print("Service IT ZONE STARTED")
    monitor = SubscriptionMonitor()

    if not check_subscription_status():
        return
    
    while not monitor.abortRequested():
        xbmc.sleep(21600000)
        check_subscription_status()

if __name__ == "__main__":
    run_service()

